import manifest from './icon-assets.json' with {type:'json'};

// Fixed public website assets, embedded into the studio config. No remote fetch
// or credential is needed to populate the icon picker.
export function hostedIconCatalog(domain){
 if(!['opencam.app','tabtabapp.net'].includes(domain))return [];
 const preferred=domain==='opencam.app'?'camera-orange':'tabs-purple';
 return manifest.assets.map(a=>({...a,url:'https://'+domain+'/email-assets/v1/'+a.file}))
  .sort((a,b)=>Number(b.id===preferred)-Number(a.id===preferred));
}
