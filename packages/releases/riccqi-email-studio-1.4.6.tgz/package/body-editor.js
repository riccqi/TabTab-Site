// Free-form authoring still stores allowlisted Markdown, never editable HTML.
// Only the body is editable; the renderer supplies the fixed branded wrapper.
export function createBodyEditor({$,changed,redraw,notify}){
 let editable=true,mode='edit',body=null,originals=new Map(),selection=null,linkTarget=null,imageTarget=null,pendingCaret=null,history=[],historyIndex=-1;
 const canvas=$('visual-editor'),surface=canvas.attachShadow({mode:'open'});
 const escape=value=>String(value??'').replace(/[\\`*_{}\[\]<>#+!|~-]/g,'\\$&');
 function safeURL(value,image=false){
  if(typeof value!=='string'||value.length>2000||/[\u0000-\u0020\u007f\\]/.test(value))return null;
  try{const u=new URL(value);if(!(image?['https:']:['https:','http:','mailto:']).includes(u.protocol)||u.username||u.password)return null;
   if(image&&['updates-api.opencam.app','updates.tabtabapp.net'].includes(u.hostname.toLowerCase()))return null;
   return u.href;
  }catch{return null;}
 }
 const destination=url=>url.replace(/\(/g,'%28').replace(/\)/g,'%29');
 function inline(node){
  if(node.nodeType===3)return escape(node.textContent);
  if(node.nodeType!==1)return '';
  const tag=node.tagName,content=()=>Array.from(node.childNodes).map(inline).join('');
  if(['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','SVG','MATH','FORM','INPUT','BUTTON','SELECT'].includes(tag))return '';
  if(tag==='BR')return '  \n';
  if(tag==='STRONG'||tag==='B')return '**'+content()+'**';
  if(tag==='EM'||tag==='I')return '*'+content()+'*';
  if(tag==='DEL'||tag==='S'||tag==='STRIKE')return '~~'+content()+'~~';
  if(tag==='CODE'){const value=node.textContent,ticks='`'.repeat(Math.max(1,...Array.from(value.matchAll(/`+/g),m=>m[0].length+1)));return ticks+' '+value+' '+ticks;}
  if(tag==='A'){const url=safeURL(node.getAttribute('href'));return url?'['+content()+']('+destination(url)+')':content();}
  if(tag==='IMG'){const url=safeURL(node.getAttribute('src'),true);return url?'!['+escape(node.getAttribute('alt'))+']('+destination(url)+')':'';}
  if(tag==='DIV'||tag==='P')return content()+'\n\n';
  return content();
 }
 function block(node){
  if(node.nodeType===3)return escape(node.textContent);
  if(node.nodeType!==1)return '';
  const saved=originals.get(node.getAttribute('data-editor-block'));
  // Unchanged legacy Markdown (including icon rows/tables) keeps its exact source.
  if(saved&&node.isEqualNode(saved.node))return saved.raw.replace(/\n+$/,'');
  const children=()=>Array.from(node.childNodes).map(block).filter(Boolean).join('\n\n');
  if(node.hasAttribute('data-editor-block')){
   if(saved?.feature){
    const image=node.querySelector('img'),anchor=node.querySelector('a');
    const f={imageUrl:safeURL(image?.getAttribute('src'),true),alt:image?.getAttribute('alt')||'',title:node.querySelector('h2')?.textContent||'',body:node.querySelector('p')?.innerText||'',url:safeURL(anchor?.getAttribute('href')),linkText:anchor?.textContent||''};
    const limits={imageUrl:2000,alt:160,title:100,body:1000,url:2000,linkText:80};
    // Keep an edited legacy row when it still fits. Deleting a field simply
    // yields ordinary body content, never a mandatory-section validation error.
    if(Object.entries(limits).every(([key,max])=>typeof f[key]==='string'&&f[key].trim()&&f[key].length<=max&&!/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(f[key]))&&f.url.startsWith('https:'))return '```email-feature\n'+JSON.stringify(f,null,2)+'\n```';
   }
   return children();
  }
  const tag=node.tagName,content=()=>Array.from(node.childNodes).map(inline).join('').trim();
  if(/^H[1-6]$/.test(tag))return '#'.repeat(Number(tag[1]))+' '+content();
  if(tag==='P')return Array.from(node.children).some(el=>/^(DIV|H[1-6]|UL|OL|BLOCKQUOTE|PRE|TABLE)$/.test(el.tagName))?children():content();
  if(tag==='DIV')return Array.from(node.children).some(el=>/^(P|DIV|H[1-6]|UL|OL|BLOCKQUOTE|PRE|TABLE)$/.test(el.tagName))?children():content();
  if(tag==='UL'||tag==='OL')return Array.from(node.children).filter(el=>el.tagName==='LI').map((li,i)=>{
   const parts=Array.from(li.childNodes).map(n=>n.nodeType===1&&/^(UL|OL)$/.test(n.tagName)?'\n'+block(n).split('\n').map(line=>'    '+line).join('\n'):n.nodeType===1&&n.tagName==='P'?Array.from(n.childNodes).map(inline).join(''):inline(n)).join('').trimEnd();
   return (tag==='OL'?(Number(node.getAttribute('start'))||1)+i+'. ':'- ')+parts;
  }).join('\n');
  if(tag==='BLOCKQUOTE')return children().split('\n').map(line=>'> '+line).join('\n');
  if(tag==='PRE'){const value=node.textContent,ticks='`'.repeat(Math.max(3,...Array.from(value.matchAll(/`+/g),m=>m[0].length+1)));return ticks+'\n'+value.replace(/\n$/,'')+'\n'+ticks;}
  if(tag==='HR')return '---';
  if(tag==='TABLE'){
   if(node.getAttribute('role')==='presentation')return children(); // Edited legacy icon row becomes ordinary body content; nothing is required.
   const rows=Array.from(node.rows).map(row=>Array.from(row.cells).map(cell=>Array.from(cell.childNodes).map(inline).join('').trim().replace(/\n/g,' ')));
   if(!rows.length)return '';const width=Math.max(...rows.map(row=>row.length)),line=row=>'| '+Array.from({length:width},(_,i)=>row[i]||'').join(' | ')+' |';
   return [line(rows[0]),line(Array(width).fill('---')),...rows.slice(1).map(line)].join('\n');
  }
  if(['THEAD','TBODY','TR','TD','TH'].includes(tag))return children();
  return inline(node).trim();
 }
 function historyButtons(){$('editor-undo').disabled=!editable||historyIndex<1;$('editor-redo').disabled=!editable||historyIndex>=history.length-1;}
 function commit(){const value=$('markdown').value;if(history[historyIndex]!==value){history=history.slice(0,historyIndex+1);history.push(value);if(history.length>100)history.shift();historyIndex=history.length-1;}historyButtons();}
 function travel(direction){const next=historyIndex+direction;if(!editable||next<0||next>=history.length)return;pendingCaret=offsets();historyIndex=next;$('markdown').value=history[next];changed(history[next].length<=$('markdown').maxLength);historyButtons();redraw();}
 function sync(){if(!body||!editable)return;const markdown=Array.from(body.childNodes).map(block).filter(value=>value.trim()).join('\n\n').trim();$('markdown').value=markdown;commit();changed(markdown.length<=$('markdown').maxLength);}
 function remember(){const s=surface.getSelection?.()||window.getSelection();if(s?.rangeCount&&body?.contains(s.anchorNode))selection=s.getRangeAt(0).cloneRange();}
 function restore(){body?.focus();if(selection&&body?.contains(selection.startContainer)){const s=surface.getSelection?.()||window.getSelection();s.removeAllRanges();s.addRange(selection);}}
 function offsets(){const s=surface.getSelection?.()||window.getSelection();if(!s?.rangeCount||!body?.contains(s.anchorNode))return null;const r=s.getRangeAt(0),a=r.cloneRange(),b=r.cloneRange();a.selectNodeContents(body);a.setEnd(r.startContainer,r.startOffset);b.selectNodeContents(body);b.setEnd(r.endContainer,r.endOffset);return [a.toString().length,b.toString().length];}
 function recover(position){if(!position)return;body.focus();const walker=document.createTreeWalker(body,NodeFilter.SHOW_TEXT),nodes=[];let n,total=0;while(n=walker.nextNode()){nodes.push({node:n,start:total});total+=n.textContent.length;}const point=offset=>{for(const item of nodes)if(offset<=item.start+item.node.textContent.length)return [item.node,Math.max(0,offset-item.start)];return nodes.length?[nodes.at(-1).node,nodes.at(-1).node.textContent.length]:[body,0];};const r=document.createRange();r.setStart(...point(position[0]));r.setEnd(...point(position[1]));const s=surface.getSelection?.()||window.getSelection();s.removeAllRanges();s.addRange(r);remember();}
 function command(name,value=null){if(!editable||!body)return;if(name==='undo'||name==='redo'){travel(name==='undo'?-1:1);return;}restore();document.execCommand(name,false,value);sync();remember();if(!['undo','redo'].includes(name)){pendingCaret=offsets();redraw();}}
 function show(next){mode=next;canvas.hidden=next!=='edit';$('email-preview').hidden=next!=='preview';$('plain-preview').hidden=next!=='plain';$('body-controls').hidden=next!=='edit'||!editable;for(const [id,value] of [['edit-message','edit'],['clean-preview','preview'],['show-text','plain']])$(id).classList.toggle('selected',value===next);}
 function render(model,force=false){
  if(!model||(!force&&(canvas.contains(document.activeElement)||$('link-dialog').open||$('body-image-dialog').open)))return;
  const doc=new DOMParser().parseFromString(model.html,'text/html');canvas.style.cssText=doc.body.getAttribute('style')||'';
  const style=document.createElement('style');style.textContent='[data-editor-body]{min-height:180px;outline:none}[data-editor-body]:focus{outline:1px dashed #b8a3ed;outline-offset:6px}[data-editor-body][data-empty=true]:before{content:"Write your email here…";color:#818594;pointer-events:none}';
  surface.replaceChildren(style,...Array.from(doc.body.childNodes));body=surface.querySelector('[data-editor-body]');if(!body)return;
  body.contentEditable=String(editable);body.setAttribute('role','textbox');body.setAttribute('aria-label','Email body');body.setAttribute('aria-multiline','true');body.spellcheck=true;
  originals=new Map();for(const el of body.querySelectorAll('[data-editor-block]'))originals.set(el.dataset.editorBlock,{node:el.cloneNode(true),raw:model.blocks[Number(el.dataset.editorBlock)].raw,feature:model.blocks[Number(el.dataset.editorBlock)].feature});
  body.dataset.empty=String(!body.textContent.trim()&&!body.querySelector('img'));selection=null;show(mode);if(pendingCaret&&mode==='edit')recover(pendingCaret);pendingCaret=null;
 }
 surface.addEventListener('input',()=>{if(body){body.dataset.empty=String(!body.textContent.trim()&&!body.querySelector('img'));sync();remember();}});
 surface.addEventListener('keydown',event=>{if(editable&&body?.contains(event.target)&&(event.metaKey||event.ctrlKey)){const key=event.key.toLowerCase();if(key==='z'||key==='y'){event.preventDefault();travel(key==='y'||event.shiftKey?1:-1);}}});
 surface.addEventListener('keyup',remember);surface.addEventListener('mouseup',remember);
 surface.addEventListener('paste',event=>{if(!editable||!body?.contains(event.target))return;event.preventDefault();document.execCommand('insertText',false,event.clipboardData?.getData('text/plain')||'');});
 surface.addEventListener('drop',event=>{event.preventDefault();if(editable)notify('Use Image to add a public HTTPS image, or paste text.');});
 surface.addEventListener('click',event=>{const anchor=event.target.closest('a');if(anchor){event.preventDefault();if(editable&&body?.contains(anchor))openLink(anchor);}else if(editable&&event.target.tagName==='IMG'&&body?.contains(event.target))openImage(event.target);});
 for(const [id,name,value] of [['body-bold','bold'],['body-italic','italic'],['body-heading','formatBlock','h2'],['body-paragraph','formatBlock','p'],['body-bullets','insertUnorderedList'],['body-numbers','insertOrderedList'],['editor-undo','undo'],['editor-redo','redo']]){
  $(id).onmousedown=event=>event.preventDefault();$(id).onclick=()=>command(name,value);
 }
 function openLink(anchor=null){remember();linkTarget=anchor;$('link-label').value=anchor?.textContent||(selection?.toString()||'');$('link-url').value=anchor?.getAttribute('href')||'';$('link-dialog').showModal();$('link-label').focus();}
 $('body-link').onmousedown=event=>event.preventDefault();$('body-link').onclick=()=>openLink();
 $('link-form').onsubmit=event=>{event.preventDefault();const url=safeURL($('link-url').value.trim()),label=$('link-label').value.trim();if(!url||!label){notify('Add link text and an HTTP, HTTPS or mailto URL.');return;}
  if(linkTarget&&body.contains(linkTarget)){linkTarget.textContent=label;linkTarget.setAttribute('href',url);}
  else {restore();const anchor=document.createElement('a');anchor.href=url;anchor.textContent=label;insert(anchor);}
  $('link-dialog').close();linkTarget=null;sync();redraw();};
 $('link-cancel').onclick=()=>$('link-dialog').close();
 function insert(node){const s=surface.getSelection?.()||window.getSelection();if(s?.rangeCount&&body.contains(s.anchorNode)){const range=s.getRangeAt(0);range.deleteContents();range.insertNode(node);range.setStartAfter(node);range.collapse(true);s.removeAllRanges();s.addRange(range);}else body.append(node);}
 function openImage(image=null){remember();imageTarget=image;$('body-image-url').value=image?.getAttribute('src')||'';$('body-image-alt').value=image?.getAttribute('alt')||'';$('body-image-dialog').showModal();$('body-image-url').focus();}
 $('body-image').onmousedown=event=>event.preventDefault();$('body-image').onclick=()=>openImage();
 $('body-image-form').onsubmit=event=>{event.preventDefault();const url=safeURL($('body-image-url').value.trim(),true),alt=$('body-image-alt').value.trim();if(!url||!alt){notify('Use a public HTTPS image URL and an image description.');return;}
  const img=imageTarget&&body.contains(imageTarget)?imageTarget:document.createElement('img');img.src=url;img.alt=alt;if(img!==imageTarget){restore();insert(img);}
  $('body-image-dialog').close();imageTarget=null;sync();redraw();};
 $('body-image-cancel').onclick=()=>$('body-image-dialog').close();
 $('edit-message').onclick=()=>show('edit');$('clean-preview').onclick=()=>{show('preview');redraw();};$('show-text').onclick=()=>{show('plain');redraw();};
 return {render,reset(){originals=new Map();body=null;selection=null;history=[$('markdown').value];historyIndex=0;pendingCaret=null;show('edit');historyButtons();},setEditable(value){editable=value;$('edit-message').disabled=!value;for(const el of document.querySelectorAll('[data-editor-control]'))el.disabled=!value;if(body)body.contentEditable=String(value);historyButtons();if(!value)show('preview');},validate(){if($('markdown').value.length>$('markdown').maxLength)throw Error('This email is too long. Shorten it before saving.');}};
}
