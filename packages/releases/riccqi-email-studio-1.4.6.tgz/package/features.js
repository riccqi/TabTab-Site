// A reserved Markdown fence describes one fixed layout, never arbitrary HTML/CSS.
const limits={imageUrl:2000,alt:160,title:100,body:1000,url:2000,linkText:80};
function https(value,image=false){
 if(!/^https:\/\//i.test(value)||/[\u0000-\u0020\u007f\\]/.test(value))return null;
 try{const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password)return null;
  if(image&&['updates-api.opencam.app','updates.tabtabapp.net'].includes(u.hostname.toLowerCase()))return null;
  return u.href;
 }catch{return null;}
}
function validate(value){
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!Object.hasOwn(limits,k)))return null;
 for(const [key,max] of Object.entries(limits))if(!Object.hasOwn(value,key)||typeof value[key]!=='string'||!value[key].trim()||value[key].length>max||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value[key]))return null;
 const imageUrl=https(value.imageUrl,true),url=https(value.url);if(!imageUrl||!url)return null;
 return {...value,imageUrl,url};
}
export function parseFeatureBlock(token){
 if(token.type!=='code'||token.lang!=='email-feature'||!/^```email-feature[ \t]*\n[\s\S]*\n```[ \t]*(?:\n)*$/.test(token.raw||''))return null;
 try{return validate(JSON.parse(token.text));}catch{return null;}
}
export function featureMarkdown(value){
 const feature=validate(value);
 if(!feature)throw new Error('An email feature needs imageUrl and url as absolute HTTPS URLs, alt, title, body and linkText. Extra fields are not supported.');
 return '```email-feature\n'+JSON.stringify(feature,null,2)+'\n```';
}
export function featureHTML(f,escape,color){
 return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 28px"><tr><td width="60" valign="top" style="padding:2px 16px 0 0"><img src="${escape(f.imageUrl)}" width="44" height="44" alt="${escape(f.alt)}" style="display:block;border:0;border-radius:12px"></td><td valign="top"><h2 style="margin:0 0 8px;font:700 20px/1.3 Arial,Helvetica,sans-serif;color:#171a25">${escape(f.title)}</h2><p style="margin:0 0 8px;line-height:1.7">${escape(f.body).replace(/\n/g,'<br>')}</p><a href="${escape(f.url)}" style="color:${escape(color)};text-decoration:underline">${escape(f.linkText)}</a></td></tr></table>`;
}
// Preserve all ordinary source text exactly; replace only valid top-level fences.
export function featurePlainText(markdown,tokens){
 const source=markdown.replace(/\r\n?/g,'\n');
 let cursor=0,end=0,text='',changed=false;
 for(const token of tokens){
  if(!token.raw)continue;
  const start=source.indexOf(token.raw,cursor);if(start<0)continue;
  cursor=start+token.raw.length;
  const f=parseFeatureBlock(token);if(!f)continue;
  text+=source.slice(end,start)+`${f.title}\n${f.body}\n${f.linkText}: ${f.url}`+(token.raw.match(/\n*$/)?.[0]||'');end=cursor;changed=true;
 }
 return changed?text+source.slice(end):markdown;
}
