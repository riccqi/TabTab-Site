// This function is serialized into the dashboard. It only saves Markdown and
// validated feature fields, never contenteditable HTML. The renderer owns HTML.
export function createVisualEditor({$,getDraft,initialIcons=[],changed,redraw,notify}){
 let blocks=[],selected=-1,editable=true,mode='edit',catalog=[],history=[],historyIndex=-1,linkTarget=null,errors='';
 const canvas=$('visual-editor'),surface=canvas.attachShadow({mode:'open'});
 const limits={title:100,body:1000,alt:160,linkText:80};
 const text=value=>String(value??'');
 const escapeMD=value=>text(value).replace(/[\\`*_{}\[\]<>#+!|~-]/g,'\\$&');
 function safeURL(value,image=false,httpsOnly=false){
  if(typeof value!=='string'||value.length>2000||/[\u0000-\u0020\u007f\\]/.test(value))return null;
  try{const u=new URL(value);if(!(image||httpsOnly?['https:']:['https:','http:','mailto:']).includes(u.protocol)||u.username||u.password)return null;
   if(image&&['updates-api.opencam.app','updates.'+'tabtabapp'+'.net'].includes(u.hostname.toLowerCase()))return null;
   return u.href;
  }catch{return null;}
 }
 catalog=(Array.isArray(initialIcons)?initialIcons:[]).filter(a=>safeURL(a.url,true)&&typeof a.alt==='string'&&a.alt.trim()).map(a=>({url:safeURL(a.url,true),alt:a.alt,label:a.label||a.alt}));
 function featureSource(f){return '```email-feature\n'+JSON.stringify(f,null,2)+'\n```';}
 function serialize(){return blocks.map(b=>b.raw.replace(/\n+$/,'')).filter(Boolean).join('\n\n')+'\n';}
 function check(){
  for(const b of blocks)if(b.feature){
   for(const [key,max] of Object.entries(limits))if(!text(b.feature[key]).trim()||b.feature[key].length>max)return 'Add '+key+' for each icon section (up to '+max+' characters).';
   if(!safeURL(b.feature.imageUrl,true)||!safeURL(b.feature.url,false,true))return 'Use absolute HTTPS URLs for icon sections.';
  }
  if($('markdown').value.length>$('markdown').maxLength)return 'This update is too long. Shorten it before saving.';
  return '';
 }
 function commit(){const value=$('markdown').value;if(history[historyIndex]!==value){history=history.slice(0,historyIndex+1);history.push(value);if(history.length>50)history.shift();historyIndex=history.length-1;}updateControls();}
 function updateControls(){
  $('section-up').disabled=!editable||selected<=0;$('section-down').disabled=!editable||selected<0||selected>=blocks.length-1;$('section-remove').disabled=!editable||selected<0;
  $('editor-undo').disabled=!editable||historyIndex<1;$('editor-redo').disabled=!editable||historyIndex>=history.length-1;
  $('selected-section').textContent=selected<0?'Click a section to select it.':'Section '+(selected+1)+' of '+blocks.length;
 }
 function select(index){selected=index;surface.querySelectorAll('[data-editor-block]').forEach(el=>el.classList.toggle('selected-section',Number(el.dataset.editorBlock)===selected));updateControls();}
 function updateSource(){
  $('markdown').value=serialize();errors=check();changed(!errors);updateControls();
 }
 function structure(fn){if(!editable)return;commit();fn();updateSource();commit();redraw();}
 function inline(node){
  if(node.nodeType===3)return escapeMD(node.textContent);
  if(node.nodeType!==1)return '';
  const tag=node.tagName;
  if(['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','SVG','MATH','FORM','INPUT','BUTTON','SELECT'].includes(tag))return '';
  const content=()=>Array.from(node.childNodes).map(inline).join('');
  if(tag==='BR')return '  \n';
  if(tag==='STRONG'||tag==='B')return '**'+content()+'**';
  if(tag==='EM'||tag==='I')return '*'+content()+'*';
  if(tag==='CODE')return '`'+text(node.textContent).replace(/`/g,'\\`')+'`';
  if(tag==='A'){const href=safeURL(node.getAttribute('href'));return href?'['+content()+']('+href.replace(/\(/g,'%28').replace(/\)/g,'%29')+')':content();}
  if(tag==='IMG'){const src=safeURL(node.getAttribute('src'),true);return src?'!['+escapeMD(node.getAttribute('alt'))+']('+src.replace(/\(/g,'%28').replace(/\)/g,'%29')+')':'';}
  if(tag==='DIV'||tag==='P')return content()+'\n\n';
  return content();
 }
 function fieldText(el){return el.innerText.replace(/\u00a0/g,' ');}
 function sync(el){
  const wrapper=el.closest('[data-editor-block]');if(!wrapper)return;
  const index=Number(wrapper.dataset.editorBlock),b=blocks[index];if(!b)return;
  if(b.feature){b.feature[el.dataset.featureField]=fieldText(el);b.raw=featureSource(b.feature);}
  else {const source=Array.from(el.childNodes).map(inline).join('').trim();b.raw=(b.type==='heading'?'#'.repeat(b.depth)+' ':'')+source;}
  updateSource();
 }
 function show(next){mode=next;canvas.hidden=next!=='edit';$('email-preview').hidden=next!=='preview';$('plain-preview').hidden=next!=='plain';$('section-controls').hidden=next!=='edit'||!editable;for(const [id,value] of [['edit-message','edit'],['clean-preview','preview'],['show-text','plain']])$(id).classList.toggle('selected',value===next);}
 function render(model,force=false){
  if(!model)return;
  if(!force&&canvas.contains(document.activeElement))return; // Preserve selection/native undo during typing.
  blocks=model.blocks;selected=Math.min(selected,blocks.length-1);errors='';
  // This is exclusively the server's escaped/allowlisted Markdown renderer output.
  const doc=new DOMParser().parseFromString(model.html,'text/html');
  canvas.style.cssText=doc.body.getAttribute('style')||'';const style=document.createElement('style');style.textContent='[data-editor-field]:focus{outline:2px solid #b8a3ed;outline-offset:2px}.selected-section{outline:1px dashed #b8a3ed;outline-offset:4px}img[role=button]{cursor:pointer}';surface.replaceChildren(style,...Array.from(doc.body.childNodes));
  for(const wrapper of surface.querySelectorAll('[data-editor-block]')){
   const b=blocks[Number(wrapper.dataset.editorBlock)];let fields=[];
   if(b.feature){for(const [selector,key] of [['h2','title'],['p','body']]){const el=wrapper.querySelector(selector);if(el){el.dataset.featureField=key;fields.push(el);}}
    const image=wrapper.querySelector('img');if(image){image.tabIndex=editable?0:-1;image.setAttribute('role','button');image.setAttribute('aria-label','Choose icon for '+b.feature.title);}
    if(!catalog.some(a=>a.url===b.feature.imageUrl))catalog.push({url:b.feature.imageUrl,alt:b.feature.alt});
   }else if(b.type==='heading'||b.type==='paragraph'){
    const el=wrapper.firstElementChild;if(el)fields=[el];
   }
   for(const el of fields){el.contentEditable=editable?(b.feature?'plaintext-only':'true'):'false';el.dataset.editorField='1';el.setAttribute('role','textbox');el.setAttribute('aria-multiline',b.type==='heading'||el.dataset.featureField==='title'?'false':'true');el.setAttribute('aria-label',b.feature?(el.dataset.featureField==='title'?'Section heading':'Section description'):(b.type==='heading'?'Email heading':'Email paragraph'));el.spellcheck=true;}
   wrapper.querySelectorAll('img').forEach(img=>img.contentEditable='false');
  }
  select(selected);show(mode);
 }
 surface.addEventListener('click',event=>{
  const wrapper=event.target.closest('[data-editor-block]');if(wrapper)select(Number(wrapper.dataset.editorBlock));
  const anchor=event.target.closest('a');if(anchor){event.preventDefault();if(editable&&wrapper)openLink(anchor,Number(wrapper.dataset.editorBlock));return;}
  if(editable&&event.target.tagName==='IMG'&&wrapper&&blocks[selected]?.feature)openIcons();
 });
 surface.addEventListener('input',event=>{const el=event.target.closest('[data-editor-field]');if(el&&editable)sync(el);});
 surface.addEventListener('paste',event=>{if(!editable)return;event.preventDefault();const value=event.clipboardData?.getData('text/plain')||'';document.execCommand('insertText',false,value);});
 surface.addEventListener('drop',event=>{event.preventDefault();if(editable)notify('Paste text to add copy; use the icon picker for images.');});
 surface.addEventListener('keydown',event=>{
  if(!editable)return;
  if(event.target.tagName==='IMG'&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openIcons();}
  if(event.key==='Enter'&&(event.target.dataset.featureField==='title'||/^H[1-6]$/.test(event.target.tagName))){event.preventDefault();event.target.blur();}
 });
 surface.addEventListener('focusout',()=>{commit();});
 function openLink(anchor,index){
  linkTarget={anchor,index};$('link-label').value=anchor.textContent;$('link-url').value=blocks[index].feature?.url||anchor.getAttribute('href')||'';$('link-dialog').showModal();$('link-label').focus();
 }
 $('link-form').onsubmit=event=>{event.preventDefault();if(!linkTarget)return;const b=blocks[linkTarget.index],href=safeURL($('link-url').value.trim(),false,!!b.feature),label=$('link-label').value.trim();if(!href||!label){notify('Add link text and a valid '+(b.feature?'HTTPS ':'')+'URL.');return;}
  commit();if(b.feature){b.feature.url=href;b.feature.linkText=label;b.raw=featureSource(b.feature);updateSource();}else{linkTarget.anchor.textContent=label;linkTarget.anchor.setAttribute('href',href);sync(linkTarget.anchor.closest('[data-editor-field]'));}
  $('link-dialog').close();linkTarget=null;commit();redraw();};
 $('link-cancel').onclick=()=>$('link-dialog').close();
 function openIcons(){
  if(!editable||!blocks[selected]?.feature)return;
  const f=blocks[selected].feature;$('icon-url').value=f.imageUrl;$('icon-alt').value=f.alt;
  const choices=$('icon-choices');choices.replaceChildren();
  for(const asset of catalog){const b=document.createElement('button');b.type='button';b.className='icon-choice';b.setAttribute('aria-label',asset.label||asset.alt);b.title=asset.label||asset.alt;const img=document.createElement('img');img.src=asset.url;img.alt=asset.alt;img.width=44;img.height=44;img.referrerPolicy='no-referrer';b.append(img);b.onclick=()=>{$('icon-url').value=asset.url;$('icon-alt').value=asset.alt;};choices.append(b);}
  $('icon-dialog').showModal();
 }
 $('icon-form').onsubmit=event=>{event.preventDefault();const url=safeURL($('icon-url').value.trim(),true),alt=$('icon-alt').value.trim();if(!url||!alt||alt.length>160){notify('Use a public HTTPS image URL and useful alt text.');return;}structure(()=>{const f=blocks[selected].feature;f.imageUrl=url;f.alt=alt;blocks[selected].raw=featureSource(f);});$('icon-dialog').close();};
 $('icon-cancel').onclick=()=>$('icon-dialog').close();
 $('import-icons').onchange=event=>loadFile(event,128000,async data=>{
  if(!Array.isArray(data.assets)||data.assets.length>100)throw Error('Choose an icon assets.json manifest (up to 100 icons).');
  const assets=data.assets.map(a=>{const url=safeURL(a.url,true);if(!url||typeof a.alt!=='string'||!a.alt.trim()||a.alt.length>160||a.width!==44||a.height!==44)throw Error('Each icon needs HTTPS, alt text and 44 × 44 display dimensions.');return {url,alt:a.alt,label:typeof a.label==='string'&&a.label.length<=200?a.label:a.alt};});
  catalog=assets;openIcons();notify('Loaded '+assets.length+' icons. Choose one, then save the icon.',false);
 });
 async function loadFile(event,max,accept){try{const file=event.target.files?.[0];if(!file)return;if(file.size>max)throw Error('This file is too large.');await accept(JSON.parse(await file.text()));}catch(e){notify(e.message);}finally{event.target.value='';}}
 $('import-update').onchange=event=>loadFile(event,40000,async d=>{
  if(typeof d.subject!=='string'||d.subject.length>200||/[\r\n]/.test(d.subject)||typeof d.preheader!=='string'||d.preheader.length>200||typeof d.markdown!=='string'||d.markdown.length>$('markdown').maxLength)throw Error('Choose a generated campaign.json file with a subject, preview text and message.');
  commit();$('subject').value=d.subject;$('preheader').value=d.preheader;$('markdown').value=d.markdown;selected=-1;errors='';changed(true);commit();await redraw();
 });
 $('section-add-text').onclick=()=>structure(()=>{blocks.push({type:'paragraph',raw:'Write your paragraph here.'});selected=blocks.length-1;});
 $('section-add-heading').onclick=()=>structure(()=>{blocks.push({type:'heading',depth:2,raw:'## Your heading'});selected=blocks.length-1;});
 $('section-add-feature').onclick=()=>structure(()=>{const asset=catalog[0]||{url:'https://assets.example.invalid/feature.png',alt:'Feature icon'};const feature={imageUrl:asset.url,alt:asset.alt,title:'Your feature heading',body:'Describe the improvement here.',url:'https://tabtabapp.net',linkText:'Learn more'};blocks.push({type:'code',feature,raw:featureSource(feature)});selected=blocks.length-1;});
 $('section-up').onclick=()=>structure(()=>{if(selected>0){[blocks[selected-1],blocks[selected]]=[blocks[selected],blocks[selected-1]];selected--;}});
 $('section-down').onclick=()=>structure(()=>{if(selected>=0&&selected<blocks.length-1){[blocks[selected+1],blocks[selected]]=[blocks[selected],blocks[selected+1]];selected++;}});
 $('section-remove').onclick=()=>structure(()=>{if(selected>=0){blocks.splice(selected,1);selected=Math.min(selected,blocks.length-1);}});
 function travel(direction){commit();const next=historyIndex+direction;if(next<0||next>=history.length)return;historyIndex=next;$('markdown').value=history[next];errors='';changed(true);redraw();updateControls();}
 $('editor-undo').onclick=()=>travel(-1);$('editor-redo').onclick=()=>travel(1);
 $('edit-message').onclick=()=>show('edit');$('clean-preview').onclick=()=>{if(check()){notify(check());return;}show('preview');redraw();};$('show-text').onclick=()=>{show('plain');redraw();};
 return {
  render,
  reset(){blocks=[];selected=-1;errors='';history=[$('markdown').value];historyIndex=0;show('edit');updateControls();},
  setEditable(value){editable=value;$('edit-message').disabled=!value;for(const el of document.querySelectorAll('[data-editor-control]'))el.disabled=!value;if(!editable)show('preview');},
  validate(){errors=check();if(errors)throw Error(errors);},
 };
}
