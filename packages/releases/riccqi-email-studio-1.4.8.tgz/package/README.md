# Shared email studio

OpenCam and TabTab use this package for the dashboard HTML/CSS/browser app, the
safe Markdown-to-email renderer, and the Resend delivery queue (`outbox.js`).

`outbox.js` owns the sending rules for both apps: each cron run claims up to 100 due
rows from the app's `deliveries` table, the app prepares each email (or skips or holds
it), and the batch goes to Resend in one request. Throttling retries with backoff (up
to 5 attempts); any outcome where Resend may have accepted the email is held as
`ambiguous` and never resent automatically; a Resend webhook event settles it. Both
apps are on Resend Pro, so there is no daily cap. Each app keeps its own database,
contacts and campaign tables, and supplies only `prepare` and a claim filter. Brand, domain, accent, source description and
sending-plan presentation are configured by each app. Contacts, settings and campaign delivery stay in each app's own Worker and
database. OpenCam hosts the shared owner login and routes authenticated TabTab
workspace requests through a Cloudflare service binding. The package itself
contains UI configuration only: API bases, auth base, asset query, and workspace
links. It contains no credentials or subscriber data.

To release a change, bump package.json, run `npm pack ./packages/email-studio
--pack-destination ./packages/releases` from the repository root, and commit the
source and resulting versioned tarball. OpenCam installs that local tarball;
TabTab pins the same tarball at an immutable GitHub commit URL. Update both lockfiles,
run both backend suites, and deploy both Workers. Never replace a released version.


## Visual email editing (1.4.3)

The email itself is the editor. Click headings or paragraphs to edit, a link to
change its label/destination, or an icon to pick a generated asset. Add headings,
paragraphs and icon sections, reorder/remove selected sections, and use Undo/Redo.
Clean preview and Plain text show the outgoing renderer's result with editing
controls removed. Desktop/mobile widths remain available.

The server returns optional editor metadata from the same Markdown tokens and
HTML template used for delivery. Clean HTML/text are unchanged by that metadata.
The editing surface uses a shadow root so dashboard CSS cannot alter email fonts,
spacing or table layout. Only selection outlines differ in editing mode. The clean
preview remains in an opaque iframe with an empty sandbox.

Only canonical Markdown and validated feature fields are saved. Contenteditable
HTML is never stored. Paste inserts text only; drops are blocked; legacy inline
formatting/links are serialized through an allowlist rather than copied as HTML.
Feature text is literal and escaped. Images/feature links require HTTPS; scripts,
HTML/CSS, event attributes and custom dimensions cannot be supplied as fields.
Older drafts open unchanged, and saving without edits preserves their source.
Existing lists, tables and code are displayed and preserved as read-only blocks;
headings, paragraphs and controlled icon rows support in-place editing.

A complete top-level `email-feature` fence is the internal storage contract for a
44px icon/title/body/link row. Invalid markers remain escaped code. See
[the local PNG workflow](../../tools/email-workflow/README.md) for examples and
asset generation. Users can import campaign.json and an icon assets.json manifest
through the editor without writing Markdown or HTML. Import is local file reading,
not uploading; assets still need public HTTPS hosting before sending.

No database migration or campaign API changes are introduced. The existing
branding, saved footer, unsubscribe tokens, authentication, CSRF, suppression,
recipient boundaries and exact-content test checks remain in place. Native text
undo is tested in Chrome; toolbar undo/redo also supports section operations.

The default icon picker uses twenty licensed PNG assets (five symbols in four
gradients), served from each app's existing website under `/email-assets/v1/`.
The catalog is embedded in the dashboard configuration; the backend never fetches
remote images. Publish assets before updating the Workers. TabTab pins the release
tarball at an immutable GitHub commit; OpenCam installs its local committed copy.

## Optional free-form body composer (1.4.4)

`createDashboard({freeformBody:true})` opts a workspace into a blank, freely
editable email body. The renderer's branded header and footer remain fixed.
Formatting, headings, lists, public HTTPS images and links are optional; there
are no mandatory sections, icon fields, numbered points or prepared imports.
The body stores allowlisted Markdown, not contenteditable HTML. Paste uses plain
text; raw HTML remains escaped; preview uses the same send renderer and an opaque
sandbox iframe. No server fetches of image URLs are introduced.

Preview requests use `editing:'body'` for body-only editing metadata. Clean HTML
and plain text are identical to a normal send render. Existing Markdown is
retained without migration. Unchanged legacy blocks retain their raw source;
valid edited legacy icon rows retain their layout. Removing their required legacy
fields yields ordinary body content instead of blocking the author.

Only TabTab opts in (both its standalone UI and the central studio's TabTab
workspace). OpenCam's composer and clean send output remain unchanged. The
immutable 1.4.7 archive is vendored by both consumers for reproducible local
builds; no package registry or new public image upload is required.

Editor selection, blank starter and body-preview metadata use explicit configuration
inside the serialized dashboard function, so Worker bundling cannot change them.
The runtime regression test resolves element IDs from the actual rendered HTML
and rejects missing controls before checking each workspace API route.

## Recoverable draft deletion and centered headers (1.4.6)

Draft rows and the editor show **Delete draft**. Confirmation moves only an
unsent draft to **Deleted drafts**; **Undo** restores it immediately, and the
Deleted drafts view offers **Restore draft** after reload. There is no permanent
delete or automatic purge. The list shows the 100 most recently deleted drafts.
The editor saves valid pending edits before deletion and cancels pending autosave
and preview work. Server conditions prevent stale saves from reviving trash.

Both app databases need their new additive draft-trash migration **before**
releasing this Worker version. Existing content is retained byte-for-byte and
`deleted_at` starts NULL. CHECK constraints prevent a trashed draft from becoming
a started campaign even through older code; started campaigns cannot be trashed.
API deletion/restore is scoped to one authenticated draft and keeps delivery
history, recipients, suppression and unsubscribe data unchanged.

Both fixed email headers contain only the genuine square app icon, centered at
64 × 64 with table alignment and top padding. There is no fixed brand name,
tagline or article headline. Body and footer rendering, and dashboard corner
icons, are unchanged. Preview and send use the same template.

Development verification uses synthetic local SQLite/D1 records and intercepted
browser APIs only. Do not delete a real draft to test a release. An older code
rollback can show trashed drafts again because it ignores `deleted_at`; retain
the new column/constraints and use a trash-aware code rollback or forward fix.

## Plain visual shell (1.4.7)

Both email templates use white backgrounds and an invisible 600px maximum-width
layout. The shell has no card border, rounded corners, shadow or footer divider.
The centered 64px genuine app icon remains fixed. The visual footer contains only
the complete supplied mailing address and a discreet underlined unsubscribe
link; the decorative updates label and redundant website link are removed.
From/Reply-To identification, address-required send guards, per-recipient
unsubscribe tokens, one-click unsubscribe headers and suppression are unchanged.
The plain-text alternative is preserved. Authored body content/styles are not
rewritten. Only the preview surface/card styling is adjusted in the dashboard;
its navigation, controls, editors and recoverable draft deletion stay intact.
This visual change requires no database migration.

TabTab's configured actual From becomes `Richard from TabTab
<richard@tabtabapp.net>`; Reply-To stays `richard@tabtabapp.net`. Sender preview
labels match. OpenCam's sender is unchanged. The TabTab signed-webhook filter
accepts this exact new label (including its quoted provider form), while keeping
legacy TabTab sender forms and rejecting other identities/domains. Releasing
this version requires the intentional TabTab `FROM_EMAIL` variable update; no
email address/domain verification, credentials or database migration changes.

New drafts start with a simple editable title and paragraph. H1 titles render centered at 36px with inline wrapping styles; paragraphs and smaller headings stay left-aligned. Existing draft source is never rewritten or given a forced title. Editing and clean preview use the same template as outgoing HTML, with a plain-text alternative.

Footer identity/address remain in each app’s existing mailing-address setting, independent from the From display name. Update only the intended identity/address lines through Settings; the exact-footer test fingerprint requires a new test before sending after any settings change. Never rewrite old campaign snapshots or user-authored draft bodies to change a footer default.
